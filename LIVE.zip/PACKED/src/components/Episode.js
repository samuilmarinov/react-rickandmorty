import React from 'react';
import Single from './Single';

const Episode = () => {
    return (
       <div>
           <Single /> 
       </div>
        
    );
}
 
export default Episode;