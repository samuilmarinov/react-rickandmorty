import React from 'react';
import Singlelocation from './Singlelocation';

const Location = () => {
    return (
       <div>
            <Singlelocation /> 
       </div>
        
    );
}
 
export default Location;