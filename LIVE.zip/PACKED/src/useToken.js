import { useState } from 'react';

export default function useToken() {
  const getToken = () => {
    var token = localStorage.getItem('token');
    return token
  };

  const [token, setToken] = useState(getToken());

  const saveToken = userToken => {
    var token = localStorage.setItem('token', JSON.stringify(userToken));  
    setToken(token);
  };

  return {
    setToken: saveToken,
    token
  }
}